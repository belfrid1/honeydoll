<?php $__env->startSection("title", "SEX-DOLLS MAIN PRODUCTS"); ?>
<?php $__env->startSection('description'); ?>
    <meta name="description" content="+1000 sex dolls in stock,  buy tpe or silicone love doll on our store, highest quality materials worlwide discreet shipping. We offer the best choices from every brands retailer. Robot sex doll, Big ass, skinny, bbw, small or big tits, brunette, asian, japanese, brazilian, indian, latina, ebony, realistic pussy.">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylesheets'); ?>
    





    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open%20Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">







<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="slider-area">
        <div class="slider-active owl-carousel nav-style-1  owl-dot-none">
            <div class="single-slider-2 slider-height-2 d-flex align-items-center bg-img" style="background-image:url(assets/img/slider/xdollkiss_slider4.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-7 col-md-8 col-12 ms-auto">
                            <div class="slider-content-3 slider-animated-1 text-center">
                                <h3 class="animated">Stylish</h3>
                                <h1 class="animated">Male Clothes</h1>
                                <p class="animated">30% off Summer Vacation</p>
                                <div class="slider-btn btn-hover">
                                    <a class="animated" href="shop.html">SHOP NOW</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-2 slider-height-2 d-flex align-items-center bg-img" style="background-image:url(assets/img/slider/xdollkiss_slider5.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-7 col-md-8 col-12 ms-auto">
                            <div class="slider-content-3 slider-animated-1 text-center">
                                <h3 class="animated">Stylish</h3>
                                <h1 class="animated">Male Clothes</h1>
                                <p class="animated">30% off Summer Vacation</p>
                                <div class="slider-btn btn-hover">
                                    <a class="animated" href="shop.html">SHOP NOW</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



















































































































































































































































































































































































































<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jscroll/2.4.1/jquery.jscroll.min.js"></script>

<script type="text/javascript">
    $('ul.pagination').hide();
    $(function() {
        $('.scrolling-pagination').jscroll({
            loadingHtml: '<img src="<?php echo e(asset('public/assets/front/images/spin.gif')); ?>" alt="Loading" /> Loading...',
            autoTrigger: true,
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.scrolling-pagination',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
    });
</script>

    <!--------------- load female product related to female criteria checked  start ------------------>
    <script  type="text/javascript">
        //  gender = document.querySelector('input[name="criteriagender"]:checked').value;//get gender selected
        choiceCheckeds = [];
        $('.js-agreement-checkbox').click(function() {
        choiceCheckedId = $(this).attr('value');
        // alert(choiceCheckedId);  //-->this will alert id of checked checkbox.

       if(this.checked){
        choiceCheckeds.unshift(choiceCheckedId);
        console.log(choiceCheckeds);
        gender = "female";

            $.ajax({
                type: "GET",
                url: "<?php echo e(route('front.choiceCheckeds')); ?>",
                data: {choiceCheckeds,gender}, //--> send id of checked checkbox on other page
                beforeSend: function(){
                    /* Show image container */
                    console.log('female criteria',choiceCheckeds);
                    $(".femalcechoiceChecked").empty();
                    $("#loader").show();
                },
                success: function(data) {
                    $("#loader").hide();
                    // $(".femalcechoiceChecked").show();
                    if(data === []) {
                        alert('No product corresponds to this criteria !');
                    }

                    $(".femalcechoiceChecked").html(data);
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {

                }
            });

            }else{
                if(choiceCheckeds.indexOf(choiceCheckedId) > -1) {
                    console.log(choiceCheckeds.indexOf(choiceCheckedId));
                    choiceCheckeds.splice (choiceCheckeds.indexOf(choiceCheckedId), 1);
                    gender = "female";
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('front.choiceCheckeds')); ?>",
                        data: {choiceCheckeds,gender}, //--> send id of checked checkbox on other page
                        beforeSend: function(){
                            /* Show image container */
                            console.log('female criteria',choiceCheckeds);
                            $(".femalcechoiceChecked").empty();
                            $("#loader").show();
                        },
                        success: function(data) {
                            console.log('success');
                            $("#loader").hide();

                            $(".femalcechoiceChecked").html(data);


                        },
                        error: function() {
                            alert('Research failed');

                        },
                        complete: function() {
                            console.log('it completed');


                        }
                    });
                }
            }

      });
    </script>
    <!--------------- load female product related to female criteria checked  end ------------------>
    <!--------------- load male product related to male criteria checked  start ------------------>
    <script  type="text/javascript">
        //  gender = document.querySelector('input[name="criteriagender"]:checked').value;//get gender selected
        choiceCheckeds = [];
        $('.js-agreement-checkbox-male').click(function() {
        choiceCheckedId = $(this).attr('value');
        // alert(choiceCheckedId);  //-->this will alert id of checked checkbox.

       if(this.checked){
        choiceCheckeds.unshift(choiceCheckedId);
        gender = "male";

            $.ajax({
                type: "GET",
                url: "<?php echo e(route('front.choiceCheckeds')); ?>",
                data: {choiceCheckeds,gender}, //--> send id of checked checkbox on other page
                beforeSend: function(){
                    /* Show image container */
                    console.log('mal criteria',choiceCheckeds);
                    $(".malchoiceChecked").empty();
                    $("#malloader").show();
                },
                success: function(data) {
                    $("#malloader").hide();
                    // $(".femalcechoiceChecked").show();

                    $(".malchoiceChecked").html(data);
                },
                 error: function() {
                    alert('Research failed');
                },
                complete: function() {
                    console.log('completed');
                }
            });

            }else{
                if(choiceCheckeds.indexOf(choiceCheckedId) > -1) {
                    console.log(choiceCheckeds.indexOf(choiceCheckedId));
                    choiceCheckeds.splice (choiceCheckeds.indexOf(choiceCheckedId), 1);
                    gender = "male";
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('front.choiceCheckeds')); ?>",
                        data: {choiceCheckeds,gender}, //--> send id of checked checkbox on other page
                        beforeSend: function(){
                            /* Show image container */
                            console.log('mal criteria',choiceCheckeds);
                            $(".malchoiceChecked").empty();
                            $("#malloader").show();
                        },
                        success: function(data) {
                            console.log('success');
                            $("#malloader").hide();

                            $(".malchoiceChecked").html(data);

                        },
                        error: function() {
                            alert('Research failed');

                        },
                        complete: function() {
                            console.log('it completed');


                        }
                    });
                }

            }

      });
    </script>
    <!--------------- load male product related to male criteria checked  start ------------------>


    <script>
        $(document).ready(function(){

            $('.main-criteria').prop('diabled',true);

            $('body').on('click','',function(){

            })
            $(".CHOICEID").on("click", function () {
                var id = $(this).data("id");
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('front.home')); ?>",
                    data: { id : id },
                    success: function (data) {
                        $("#PRODUCTDIV").load(location.href + " #PRODUCTDIV");
                    }

                });
            });
        });
    </script>


<script >
    //     $(document).ready(function(){
    //
    //         var URL = "https://www.joylovedolls.com/?sca_ref=857178.sMDlwaxRwC";
    //         var win = window.open(URL, 'blanck');
    //
    //         var URLtwo = "https://sexdollgenie.com/?aff=83";
    //         var win = window.open(URLtwo, '_blanck');
    //
    //         var URLthree = "https://www.siliconwives.com/?ref=5db67d9ddb4d2";
    //         var win = window.open(URLthree,  '__blanck');
    //
    //         var URLfour = "https://gemsexdoll.com/?wpam_id=9";
    //         var win = window.open(URLfour, '___blanck');
    //         sessionStorage.setItem('anyEvent', "scroll");
    //
    // });

    // });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("front.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/honeydoll/resources/views/front/landingpage.blade.php ENDPATH**/ ?>