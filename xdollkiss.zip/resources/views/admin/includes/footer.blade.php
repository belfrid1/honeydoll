<footer class="main-footer">
    <strong>Copyright &copy; <script>document.write(new Date().getFullYear());</script> : <a href="#">{{ config('app.name', 'AFFLIATE PRODUCT') }}</a> -</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
</footer>
